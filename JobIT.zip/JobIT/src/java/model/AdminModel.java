/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class AdminModel {
    String id,username,password;
     KoneksiDB db = null;

    public AdminModel() {
        db = new KoneksiDB();
    }

    public String getId() {
        return id;
    }

    public void setId(String admin_id) {
        this.id = admin_id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public List LoginAdmin(String user, String password) {
        List dataAdmin = new ArrayList();
        ResultSet rs = null;
        try {
            String sql = "select * from adminlogin where username='" + user + "' and password='" + password + "'";
            rs = db.ambilData(sql);
            while (rs.next()) {
                AdminModel am = new AdminModel();
                am.setId(rs.getString("admin_id"));
                am.setUsername(rs.getString("username"));               
                am.setPassword(rs.getString("password"));
                dataAdmin.add(am);
            }
            db.diskonek(rs);
        } catch (Exception a) {
            System.out.println("Terjadi kesalahaan cari login admin, pada :\n" + a);
        }
        return dataAdmin;
    }
}