package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.UserModel;

public class Registration extends HttpServlet {

    Connection con;
    PreparedStatement pst;
    PreparedStatement pst1;
    ResultSet rs;
   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try 
        {
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/jobit", "root", "");
            String fname = request.getParameter("fn");
            String pass = request.getParameter("pass");
            String email = request.getParameter("em");
            String phone = request.getParameter("pn");
            String uname = request.getParameter("un");
            String gender = request.getParameter("gender");

            String sql = "insert into userdata(username, password, email, phnum, fullname, gender) values(?,?,?,?,?,?)";
            pst=con.prepareStatement(sql); 
            pst.setString(1, uname);
            pst.setString(2, pass); 
            pst.setString(3, email);
            pst.setString(4, phone);
            pst.setString(5, fname);
            pst.setString(6, gender);
            pst.executeUpdate();
            rs = pst1.executeQuery();
            rs.next();

        } catch (ClassNotFoundException ex) {
           ex.printStackTrace();
        } catch (SQLException ex) {
           ex.printStackTrace();
        }
    }
}